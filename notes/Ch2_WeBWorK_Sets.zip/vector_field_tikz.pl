######################################################################
## vector_field_tikz -- direction field for a 2D autonomous system
##   dx/dt = f(x,y), dy/dt = g(x,y)
## Companion to slope_field_tikz (see Useful Coding Notes). Requires
## "PGtikz.pl" in loadMacros.
##
## Call: vector_field_tikz($f, $g, $xmin, $xmax, $ymin, $ymax, $step)
##   $f, $g : Perl coderefs  sub { my ($x,$y) = @_; return ...; }
## Arrows are normalized (direction only), anchored ON grid points
## (unlike slope fields, which use cell centers) so behavior along the
## axes -- often invariant lines -- is visible. Zero vectors are drawn
## as dots. Statements are joined with a plain space: every TikZ
## statement already ends in ';', so no separator command is needed.
######################################################################
sub vector_field_body {
    my ($f, $g, $xmin, $xmax, $ymin, $ymax, $step) = @_;
    my $half = 0.4 * $step;
    my @lines;
    for (my $x = $xmin + $step; $x <= $xmax - $step + 1e-9; $x += $step) {
        for (my $y = $ymin + $step; $y <= $ymax - $step + 1e-9; $y += $step) {
            my ($u, $v) = ($f->($x, $y), $g->($x, $y));
            my $r = sqrt($u*$u + $v*$v);
            if ($r < 1e-9) {
                push @lines, sprintf(' \fill[blue] (%.4f,%.4f) circle (0.05);', $x, $y);
                next;
            }
            my ($dx, $dy) = ($half*$u/$r, $half*$v/$r);
            push @lines, sprintf(
                ' \draw[blue,->,>=stealth] (%.4f,%.4f) -- (%.4f,%.4f);',
                $x - $dx, $y - $dy, $x + $dx, $y + $dy);
        }
    }
    return join(' ', @lines);
}

sub vector_field_tikz {
    my ($f, $g, $xmin, $xmax, $ymin, $ymax, $step) = @_;
    my $body = vector_field_body($f, $g, $xmin, $xmax, $ymin, $ymax, $step);
    my $grid = 2 * $step;
    my (@gx, @gy);
    for (my $t = $xmin; $t <= $xmax + 1e-9; $t += $grid) { push @gx, sprintf('%g', $t); }
    for (my $t = $ymin; $t <= $ymax + 1e-9; $t += $grid) { push @gy, sprintf('%g', $t); }
    my $gxl = join(',', @gx);
    my $gyl = join(',', @gy);
    my $txl = join(',', grep { $_ != 0 && $_ != $xmin && $_ != $xmax } @gx);
    my $tyl = join(',', grep { $_ != 0 && $_ != $ymin && $_ != $ymax } @gy);

    my $tikz = <<'END_TIKZ';
\foreach \gx in {GXL} \draw[gray!40,dashed,thin] (\gx,YMIN) -- (\gx,YMAX);
\foreach \gy in {GYL} \draw[gray!40,dashed,thin] (XMIN,\gy) -- (XMAX,\gy);
\draw[->,thick] (XMIN,0) -- (XMAX,0) node[right] {\(x\)};
\draw[->,thick] (0,YMIN) -- (0,YMAX) node[above] {\(y\)};
BODYHERE
\foreach \gx in {TXL} \node[below,font=\small,inner sep=1pt] at (\gx,-0.08) {\(\gx\)};
\foreach \gy in {TYL} \node[left,font=\small,inner sep=1pt] at (-0.08,\gy) {\(\gy\)};
\draw[thick] (XMIN,YMIN) rectangle (XMAX,YMAX);
END_TIKZ

    $tikz =~ s/XMIN/$xmin/g;  $tikz =~ s/XMAX/$xmax/g;
    $tikz =~ s/YMIN/$ymin/g;  $tikz =~ s/YMAX/$ymax/g;
    $tikz =~ s/GXL/$gxl/;     $tikz =~ s/GYL/$gyl/;
    $tikz =~ s/TXL/$txl/;     $tikz =~ s/TYL/$tyl/;
    $tikz =~ s/BODYHERE/$body/;

    my $image = createTikZImage();
    $image->ext('svg') if $displayMode ne 'TeX';
    $image->tex($tikz);
    return $image;
}
